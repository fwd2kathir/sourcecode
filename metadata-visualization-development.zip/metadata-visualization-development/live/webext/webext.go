package webext

import (
	// "bufio"
	. "eaciit/scbmetadata/live/controllers"
	. "eaciit/scbmetadata/live/helper"
	"strconv"

	lacl "github.com/eaciit/acl/v1.0"
	// "github.com/eaciit/dbox"
	"log"
	"os"
	"path/filepath"

	//_ "github.com/eaciit/dbox/dbc/mongo"
	"github.com/eaciit/knot/knot.v1"
	"github.com/eaciit/toolkit"
	// "strings"
	//"time"
)

var (
	Version string = "live"
	wd             = func() string {
		path, _ := os.Executable()
		d := filepath.Dir(path)
		return filepath.Join(d) + toolkit.PathSeparator
	}()
	// wd = func() string {
	// 	d, _ := os.Getwd()
	// 	return filepath.Join(d)
	// }()
)

func init() {
	log.Println("___INIT START_____")
	//conn, err := PrepareConnection()
	// if err != nil {
	// 	log.Println(err)
	// }
	uploadPath := PrepareUploadPath()
	config := ReadConfig()
	//ctx := orm.New(conn)
	baseCtrl := new(BaseController)
	//baseCtrl.Ctx = ctx
	baseCtrl.UploadPath = uploadPath
	baseCtrl.Path = config["path"]
	baseCtrl.AccessKeyID = config["accesskeyid"]
	baseCtrl.SecretAccessKey = config["secretaccesskey"]
	baseCtrl.Endpoint = config["endpoint"]
	baseCtrl.AccAmazone = config["accamazone"]
	baseCtrl.Attachemail = config["attachemail"]

	baseCtrl.SMTPAddress = config["smtpaddr"]
	_smtpPort := config["smtpport"]
	smtpPortInt, _ := strconv.Atoi(_smtpPort)
	baseCtrl.SMTPPort = smtpPortInt
	baseCtrl.SMTPUsername = config["smtpuser"]
	baseCtrl.SMTPPassword = config["smtppassword"]
	baseCtrl.SenderMail = config["sendermail"]
	baseCtrl.SenderName = config["sendername"]

	baseCtrl.AppStatus = config["appstatus"]
	baseCtrl.AppUrl = config["appurl"]

	baseCtrl.Username = config["username"]
	baseCtrl.Password = config["password"]
	baseCtrl.Source = config["source"]
	baseCtrl.Host = config["host"]
	baseCtrl.Database = config["database"]

	//acl db
	//lacl.SetExpiredDuration(time.Hour * 2)
	//err = lacl.SetDb(conn)
	/*if err != nil {
		log.Println(err)
	}*/

	/*err = PrepareDefaultUser()
	if err != nil {
		log.Println(err)
	}*/
	//==

	app := knot.NewApp(Version)
	app.ViewsPath = filepath.Join(wd, Version, "views") + toolkit.PathSeparator

	// app.ViewsPath = config["path"] + "views/"
	//app.Register(&AclUserController{baseCtrl})
	//app.Register(&AclSysAdminController{baseCtrl})
	app.Register(&LoginController{baseCtrl})
	app.Register(&LogoutController{baseCtrl})
	app.Register(&DashboardController{baseCtrl})
	//app.Register(&MenuSettingController{baseCtrl})

	staticpath := filepath.Join(config["path"], Version, "assets") + toolkit.PathSeparator
	app.Static("static", staticpath)
	app.LayoutTemplate = "_layout.html"
	knot.RegisterApp(app)
	log.Println("___INIT FINISH_____")
}

func PrepareUploadPath() string {
	config := ReadConfig()
	return config["uploadPath"]
}

func PrepareDefaultUser() (err error) {
	username := "eaciit"
	password := "Password.1"

	user := new(lacl.User)
	err = lacl.FindUserByLoginID(user, username)

	if err == nil || user.LoginID == username {
		return
	}

	user.ID = toolkit.RandomString(32)
	user.LoginID = username
	user.FullName = username
	user.Password = password
	user.Enable = true

	err = lacl.Save(user)
	if err != nil {
		return
	}
	err = lacl.ChangePassword(user.ID, password)
	if err != nil {
		return
	}

	toolkit.Printf(`Default user "%s" with standard password has been created%s`, username, "\n")

	return
}
