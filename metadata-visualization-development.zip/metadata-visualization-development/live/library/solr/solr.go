package solr

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/buger/jsonparser"
	"github.com/eaciit/toolkit"
	//"sort"
	"crypto/sha1"
	//"strings"
	"strconv"
)

func HTTPPost(url string, headers [][]string, payload *[]byte) ([]byte, error) {
	var (
		request *http.Request
		err     error
	)
	client := &http.Client{}
	//request
	if payload == nil {
		request, err = http.NewRequest("POST", url, nil)
	} else {
		request, err = http.NewRequest("POST", url, bytes.NewReader(*payload))
	}
	if err != nil {
		return nil, err
	}

	//add headers (content type)
	if len(headers) > 0 {
		for i := range headers {
			request.Header.Add(headers[i][0], headers[i][1])
		}
	}
	a, b, _ := resFromreq(client, request)
	return a, b
}

var cacheDir = "cache/"

func readCache(url string) (bool, []byte) {
	b := []byte(url)
	hashed := sha1.Sum(b)
	filename := fmt.Sprintf("%x.cache", hashed)
	fStat, err := os.Stat(cacheDir + filename)
	//fmt.Println(filename)
	if os.IsNotExist(err) {
		// path/to/whatever does not exist
		//fmt.Println(url,filename,"not exist")
		return false, nil
	}
	//fmt.Println(time.Now(),fStat.ModTime())
	now := time.Now()
	hour, _, _ := now.Clock()
	//fmt.Println(hour)
	if now.Sub(fStat.ModTime()).Hours() > 25 && hour < 18 {
		//fmt.Println("cache out ot date")
		return false, nil
	}
	res, _ := ioutil.ReadFile(cacheDir + filename)
	if len(res) > 0 {
		return true, res
	} else {
		return false, nil
	}

}
func writeCache(url string, data []byte) error {
	b := []byte(url)
	hashed := sha1.Sum(b)
	filename := fmt.Sprintf("%x.cache", hashed)
	err := ioutil.WriteFile(cacheDir+filename, data, 0777)
	return err
}

var client = &http.Client{}

func HTTPGet(url string, headers [][]string) ([]byte, error) {
	//fmt.Println(url)
	//client := &http.Client{}
	//request
	request, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}

	//add headers (content type)
	if len(headers) > 0 {
		for i := range headers {
			request.Header.Add(headers[i][0], headers[i][1])
		}
	}
	a, b, _ := resFromreq(client, request)
	return a, b
}
func HTTPGetCache(url string, headers [][]string) ([]byte, error) {
	//fmt.Println(url)
	splitIdx := strings.Index(url, "solr")
	urlSplited := url[splitIdx+4:] //strings.Split(url, "solr")
	//fmt.Println(urlSplited[1])
	client := &http.Client{}
	ad, res := readCache(urlSplited)
	if !ad {
		//request
		request, err := http.NewRequest("GET", url, nil)
		if err != nil {
			return nil, err
		}

		//add headers (content type)
		if len(headers) > 0 {
			for i := range headers {
				request.Header.Add(headers[i][0], headers[i][1])
			}
		}
		//return resFromreq(client, request)
		res, err2, statCode := resFromreq(client, request)
		if err2 == nil {
			if statCode == 200 {
				go writeCache(urlSplited, res)
			}
			return res, nil
		} else {
			fmt.Println(err2.Error())
			return res, err
		}

	}
	return res, nil
}

func resFromreq(client *http.Client, request *http.Request) ([]byte, error, int) {
	//response from request
	//start := time.Now()
	response, err := client.Do(request)
	if err != nil {
		return nil, err, 404
	}
	defer response.Body.Close()
	//dur := time.Since(start)
	//fmt.Println("SOLR Taking ", dur.Seconds(), "to response", request.URL.Query()["q"])
	//readall body
	body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return nil, err, 404
	}

	return body, nil, response.StatusCode
}

type ConnectionInfo struct {
	Url   *url.URL
	Core  string
	Cache bool
}

func NewConnection(host string, port int, core string) (*ConnectionInfo, error) {
	if len(host) == 0 {
		return nil, fmt.Errorf("Invalid hostname (must be length >= 1)")
	}

	if port <= 0 || port > 65535 {
		return nil, fmt.Errorf("Invalid port (must be 1..65535")
	}
	utar := fmt.Sprintf("http://%s:%d/solr", host, port)
	// u, err := url.ParseRequestURI(strings.TrimRight(utar, "/"))
	u, err := url.ParseRequestURI(utar)
	if err != nil {
		return nil, err
	}

	return &ConnectionInfo{Url: u, Core: core, Cache: true}, nil
}

type Query struct {
	params *url.Values
}

type Document struct {
	Fields map[string]interface{}
}

type FacetCount struct {
	Value string
	Count int
}

var facet_chunk_size int = 2

type Facet struct {
	Name   string
	Counts []FacetCount
}

type FacetJson struct {
	Name   string
	Counts []map[string]interface{}
}

type DocumentCollection struct {
	Stats           Stats
	FacetQueries    []FacetCount
	Facets          []Facet
	FacetsJson      []FacetJson
	FacetRanges     []Facet
	Collection      []Document
	NumFacetQueries int
	NumFacets       int
	NumFound        int
	Start           int
}

type Stats struct {
	// StatsFields []DocStatsFields
	// StatsFacet  []DocStatsFacet
	StatsFields map[string]interface{}
	StatsFacet  map[string]interface{}
}

// type DocStatsFields struct {
// 	Name   string
// 	Fields map[string]interface{}
// }

// type DocStatsFacet struct {
// 	Name   string
// 	Fields map[string]interface{}
// }

type SelectResponse struct {
	Results *DocumentCollection
	Status  int
	QTime   int
}

type UpdateResponse struct {
	Success bool
}

type ErrorResponse struct {
	Message string
	Status  int
}

type AdminResponse struct {
	Results *DocumentAdmins
	Status  int
	QTime   int
}

type DocumentAdmins struct {
	Collections []string
	Status      map[string]interface{}
	Success     map[string]interface{}
	// Errors      ErrorResponse
}

func GetShardServer(core string) string {
	shard1 := fmt.Sprintf("192.168.0.230:8983/solr/%s", core)
	shard2 := fmt.Sprintf("192.168.0.230:8984/solr/%s", core)
	shard3 := fmt.Sprintf("192.168.0.230:8985/solr/%s", core)

	return fmt.Sprintf("%s,%s,%s", shard1, shard2, shard3)
}

func (c *ConnectionInfo) ResourceAdmin(source string, params *url.Values) (*AdminResponse, error) {
	headers := [][]string{{"Content-Type", "application/json"}}
	params.Set("wt", "json")
	//params.Set("shards", GetShardServer(c.Core))
	//params.Set("shards.tolerant", "true")

	body, err := HTTPGet(fmt.Sprintf("%s/%s/%s?%s", c.Url.String(), c.Core, source, params.Encode()), headers)
	if err != nil {
		return nil, err
	}

	admres, err := GetCollResFromHTTPRes(body)
	if err != nil {
		return nil, err
	}

	return admres, nil
}

func (c *ConnectionInfo) Resource(source string, params *url.Values) (*SelectResponse, error) {
	headers := [][]string{{"Content-Type", "application/json"}}
	params.Set("wt", "json")
	//params.Set("shards", GetShardServer(c.Core))
	params.Set("shards.tolerant", "true")
	//params.Set("timeAllowed","100")
	/*unsortedParam := []string{}
	  for k,_:=range *params{
	      fmt.Println(params.Get(k))
	      unsortedParam = append(unsortedParam,k)
	  }
	  sortedParam := sort.StringSlice(unsortedParam)
	  sortedParam.Sort()
	  sortedEncodde := ""
	  for i:=range sortedParam{
	      sortedEncodde+=sortedParam[i]+"="+url.QueryEscape(params.Get(sortedParam[i]))
	      if i<len(sortedParam)-1{
	          sortedEncodde+="&"
	      }
	  }*/
	//sortedEncodde = strings.Replace(sortedEncodde," ","%20")
	//fmt.Println(sortedEncodde)
	//fmt.Println(params.Encode())
	var body []byte
	var err error
	if c.Cache {
		body, err = HTTPGetCache(fmt.Sprintf("%s/%s/%s?%s", c.Url.String(), c.Core, source, params.Encode()), headers)
	} else {
		body, err = HTTPGet(fmt.Sprintf("%s/%s/%s?%s", c.Url.String(), c.Core, source, params.Encode()), headers)
	}

	if err != nil {
		return nil, err
	}
	//fmt.Println(string(body))
	selres, err := SelectResFromHTTPRes(body)
	if err != nil {
		return nil, err
	}
	return selres, nil
}

func (c *ConnectionInfo) UpdateSingle(source string, data toolkit.M, params *url.Values) (*UpdateResponse, error) {
	payload, err := MJSONSToBytes(data)
	if err != nil {
		return nil, err
	}

	body, err := REQPost(c, payload, source, params)
	if err != nil {
		return nil, err
	}

	parseBody, err := BytesToJSONS(&body)
	if err != nil {
		return nil, err
	}
	error, report := StatusErrorResponse((*parseBody).(map[string]interface{}))
	if error {
		return nil, fmt.Errorf(fmt.Sprintf("%s", *report))
	}

	return &UpdateResponse{true}, nil
}

func (c *ConnectionInfo) UpdateMulti(source string, data toolkit.Ms, params *url.Values) (*UpdateResponse, error) {
	payload, err := MSJSONSToBytes(data)
	if err != nil {
		return nil, err
	}

	body, err := REQPost(c, payload, source, params)
	if err != nil {
		return nil, err
	}

	parseBody, err := BytesToJSONS(&body)
	if err != nil {
		return nil, err
	}

	error, report := StatusErrorResponse((*parseBody).(map[string]interface{}))
	if error {
		return nil, fmt.Errorf(fmt.Sprintf("%s", *report))
	}

	return &UpdateResponse{true}, nil
}

func REQPost(c *ConnectionInfo, payload *[]byte, source string, params *url.Values) ([]byte, error) {
	if params == nil {
		params = &url.Values{}
	}
	headers := [][]string{{"Content-Type", "application/json"}}
	params.Set("wt", "json")
	params.Set("shards", GetShardServer(c.Core))
	params.Set("shards.tolerant", "true")

	body, err := HTTPPost(fmt.Sprintf("%s/%s/%s?%s", c.Url.String(), c.Core, source, params.Encode()), headers, payload)
	if err != nil {
		return nil, err
	}

	return body, nil
}

func (c *ConnectionInfo) AddSingle(tm toolkit.M, q *Query) (*UpdateResponse, error) {
	source := "update/json/docs"
	resp, err := c.UpdateSingle(source, tm, q.params)
	return resp, err
}

func (c *ConnectionInfo) AddMulti(tms toolkit.Ms, q *Query) (*UpdateResponse, error) {
	resp, err := c.UpdateMulti("update", tms, q.params)
	return resp, err
}

func (c *ConnectionInfo) EditSingle(tm toolkit.M, q *Query) (*UpdateResponse, error) {
	source := "update/json/docs"
	resp, err := c.UpdateSingle(source, tm, q.params)
	return resp, err
}
func (c *ConnectionInfo) EditMulti(tms toolkit.Ms, q *Query) (*UpdateResponse, error) {
	resp, err := c.UpdateMulti("update", tms, q.params)
	return resp, err
}

func (c *ConnectionInfo) Delete(tm toolkit.M, q *Query) (*UpdateResponse, error) {
	data := toolkit.M{"delete": tm}
	resp, err := c.UpdateSingle("update", data, q.params)
	return resp, err
}
func (c *ConnectionInfo) DeleteALL(q *Query) (*UpdateResponse, error) {
	data := toolkit.M{"delete": toolkit.M{"query": "*:*"}} //, "commitWithin": "500"}}
	resp, err := c.UpdateSingle("update", data, q.params)
	return resp, err
}
func (q *Query) GetParams() *url.Values {
	return q.params
}
func (c *ConnectionInfo) Select(q *Query) (*SelectResponse, error) {
	resp, err := c.Resource("select", q.params)
	return resp, err
}

func SelectResFromHTTPRes(b []byte) (*SelectResponse, error) {
	j, err := BytesToJSONS(&b)
	if err != nil {
		return nil, err
	}

	resp, err := BuildRes(j)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

//API admin
func (c *ConnectionInfo) GetCollections(q *Query) (*AdminResponse, error) {
	resp, err := c.ResourceAdmin("collections", q.params)
	return resp, err
}

func (c *ConnectionInfo) ReloadCollection(q *Query) (*AdminResponse, error) {
	resp, err := c.ResourceAdmin("collections", q.params)
	return resp, err
}

func (c *ConnectionInfo) GetInfoSystem(q *Query) (*AdminResponse, error) {
	resp, err := c.ResourceAdmin("info/system", q.params)
	return resp, err
}

func GetCollResFromHTTPRes(b []byte) (*AdminResponse, error) {
	j, err := BytesToJSONS(&b)
	if err != nil {
		return nil, err
	}

	resp, err := BuildResAdmin(j)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func BytesToJSONS(b *[]byte) (*interface{}, error) {
	var container interface{}
	err := json.Unmarshal(*b, &container)

	if err != nil {
		return nil, err
	}

	return &container, nil
}

func MJSONSToBytes(m toolkit.M) (*[]byte, error) {
	b, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}

	return &b, nil
}

func MSJSONSToBytes(m toolkit.Ms) (*[]byte, error) {
	b, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}

	return &b, nil
}

func BuildResAdmin(j *interface{}) (*AdminResponse, error) {
	r := AdminResponse{}
	r_header := (*j).(map[string]interface{})["responseHeader"].(map[string]interface{})
	if r_header != nil {
		r.Status = int(r_header["status"].(float64))
		r.QTime = int(r_header["QTime"].(float64))
	}
	response_root := (*j).(map[string]interface{})

	errorsres, ok := response_root["error"].(interface{})
	if ok {
		errdat := errorsres.(map[string]interface{})
		if errorsres != nil {
			return nil, fmt.Errorf("%s (missing response) code %.0f", errdat["msg"].(string), errdat["code"].(float64))
		}
	}

	collections, ok := response_root["collections"].(interface{})
	if ok {
		coll := collections.([]interface{})
		if coll != nil {
			docAdmin := DocumentAdmins{}
			for _, v := range coll {
				docAdmin.Collections = append(docAdmin.Collections, v.(string))
			}
			r.Results = &docAdmin
		}
	}

	success, ok := response_root["success"].(interface{})
	if ok {
		succ := success.(map[string]interface{})
		if succ != nil {
			asuccdat := map[string]interface{}{}
			for k, v := range succ {
				asuccdat[k] = v.(map[string]interface{})
			}

			r.Results = &DocumentAdmins{Status: asuccdat}
		}
	}

	//information system
	docInfoAdmin := map[string]interface{}{}
	mode, ok := response_root["mode"].(interface{})
	if ok {
		imod := mode.(string)
		docInfoAdmin["mode"] = imod
	}
	zkHost, ok := response_root["zkHost"].(interface{})
	if ok {
		izkHst := zkHost.(string)
		docInfoAdmin["zkHost"] = izkHst
	}
	solrHome, ok := response_root["solr_home"].(interface{})
	if ok {
		isolrHm := solrHome.(string)
		docInfoAdmin["solr_home"] = isolrHm
	}
	infoLucene, ok := response_root["lucene"].(interface{})
	if ok {
		ilucene := infoLucene.(map[string]interface{})
		docInfoAdmin["lucene"] = ilucene
	}
	infoJvm, ok := response_root["jvm"].(interface{})
	if ok {
		ijvm := infoJvm.(map[string]interface{})
		docInfoAdmin["jvm"] = ijvm
	}
	infoSystem, ok := response_root["system"].(interface{})
	if ok {
		isystem := infoSystem.(map[string]interface{})
		docInfoAdmin["system"] = isystem

		r.Results = &DocumentAdmins{Success: docInfoAdmin}
	}

	return &r, nil
}
func BuildRes2(j []byte) (*SelectResponse, error) {
	//fmt.Println("LLLL")
	r := &SelectResponse{}
	response, _, _, err := jsonparser.Get(j, "response")

	if err != nil {
		return nil, err
	}
	responseHeader, _, _, err := jsonparser.Get(j, "responseHeader")
	if err != nil {
		return nil, err
	}
	a, _ := jsonparser.GetInt(responseHeader, "status")
	b, _ := jsonparser.GetInt(responseHeader, "QTime")
	r.Status = int(a)
	r.QTime = int(b)
	_, _, _, err = jsonparser.Get(response, "docs")
	if err != nil {
		return nil, err
	}
	num_found, _ := jsonparser.GetInt(response, "numFound")
	coll := DocumentCollection{}
	coll.NumFound = int(num_found)
	ds := make([]Document, 0, 600)
	docLen := 0
	jsonparser.ArrayEach(response, func(value []byte, detectedType jsonparser.ValueType, offset int, err error) {
		//fmt.Println(string(value))
		newDoc := Document{}
		newDoc.Fields = map[string]interface{}{}
		jsonparser.ObjectEach(value, func(key []byte, value []byte, dataType jsonparser.ValueType, offset int) error {
			//fmt.Println(string(key),":",string(value),dataType.String())
			if dataType == jsonparser.String {
				newDoc.Fields[string(key)], _ = jsonparser.ParseString(value)
			} else if dataType == jsonparser.Number {
				newDoc.Fields[string(key)], _ = jsonparser.ParseFloat(value)
				/*if strings.Contains(string(value),"."){
				      newDoc.Fields[string(key)],_ = jsonparser.ParseFloat(value)

				  }else{
				      b,_ := jsonparser.ParseInt(value)
				      newDoc.Fields[string(key)] = int(b)
				  }*/
			} else if dataType == jsonparser.Array {
				pp := []interface{}{}
				jsonparser.ArrayEach(value, func(valueA []byte, detectedType2 jsonparser.ValueType, offset int, err error) {
					if detectedType2 == jsonparser.String {
						b, _ := jsonparser.ParseString(valueA)
						pp = append(pp, b)

					} else if detectedType2 == jsonparser.Number {
						b, _ := jsonparser.ParseFloat(valueA)
						pp = append(pp, b)
						/*if strings.Contains(string(valueA),"."){
						      b,_:=jsonparser.ParseFloat(valueA)
						      pp = append(pp,b)
						  }else{
						      b,_:=jsonparser.ParseInt(valueA)
						      pp = append(pp,int(b))
						  }*/
					}

				})
				newDoc.Fields[string(key)] = pp
			}

			return nil
		})
		ds = append(ds, newDoc)
		//fmt.Println(">>>>>>>")
		docLen += 1
	}, "docs")
	coll.Collection = ds
	r.Results = &coll
	facet_response, _, _, err := jsonparser.Get(j, "facet_counts")
	if err == nil {
		facet_counts := facet_response
		facet_fields, _, _, err := jsonparser.Get(facet_counts, "facet_fields") //facet_fields := facet_counts["facet_fields"]
		facets := []Facet{}
		if err == nil {
			jsonparser.ObjectEach(facet_fields, func(key []byte, value []byte, dataType jsonparser.ValueType, offset int) error {
				f := Facet{Name: string(key)}
				fCount := [][]byte{}
				jsonparser.ArrayEach(value, func(valueA []byte, detectedType2 jsonparser.ValueType, offset int, err error) {
					fCount = append(fCount, valueA)
				})
				//chunked := chunk(fCount,facet_chunk_size)
				lc := len(fCount)
				for i := 0; i < lc; i += 2 {
					fValue := string(fCount[i])
					fCount, _ := strconv.Atoi(string(fCount[i+1]))
					f.Counts = append(f.Counts, FacetCount{
						Value: fValue,
						Count: fCount,
					})
				}
				facets = append(facets, f)

				return nil
			})
			r.Results.Facets = facets
			r.Results.NumFacets = len(facets)
		}
	}
	//fmt.Println(">>>>>",r.Results.NumFacets)
	//fmt.Println(string(docs))
	return r, nil
}
func BuildRes(j *interface{}) (*SelectResponse, error) {
	response_root := (*j).(map[string]interface{})
	response := response_root["response"]
	if response == nil {
		err, report := StatusErrorResponse(response_root)
		if err {
			return nil, fmt.Errorf(fmt.Sprintf("(error code:%v)(msg:%s)", report.Status, report.Message))
		}
		// return nil, fmt.Errorf("Supplied interface appears invalid (missing response)")
	}

	r := SelectResponse{}
	r_header := (*j).(map[string]interface{})["responseHeader"].(map[string]interface{})
	if r_header != nil {
		r.Status = int(r_header["status"].(float64))
		r.QTime = int(r_header["QTime"].(float64))
	}

	docs := response.(map[string]interface{})["docs"].([]interface{})
	if docs != nil {
		num_found := int(response.(map[string]interface{})["numFound"].(float64))
		num_results := len(docs)

		coll := DocumentCollection{}
		coll.NumFound = num_found

		ds := make([]Document, 0, num_results) //ds := []Document{}

		for i := 0; i < num_results; i++ {
			ds = append(ds, Document{docs[i].(map[string]interface{})})
		}

		coll.Collection = ds
		r.Results = &coll
	}
	facetjson_response, ok := response_root["facets"].(interface{})
	if ok == true {
		facet_counts := facetjson_response.(map[string]interface{})
		if facet_counts != nil {
			facets := make([]FacetJson, 0, len(facet_counts)) //facets := []FacetJson{}

			for key, val := range facet_counts {
				if key != "count" {
					fctFacets := FacetJson{}
					fctFacets.Name = key
					fctFacetsCount := []map[string]interface{}{}

					valBck := val.(map[string]interface{})["buckets"]
					for _, valFctCount := range valBck.([]interface{}) {
						ssVal := valFctCount.(map[string]interface{})
						fctFacetsCountAll := map[string]interface{}{}
						for keySSVal, valSSVal := range ssVal {
							if keySSVal == "val" {
								fctFacetsCountAll[keySSVal] = valSSVal.(string)
							} else {
								fctFacetsCountAll[keySSVal] = valSSVal.(float64)
							}
						}
						fctFacetsCount = append(fctFacetsCount, fctFacetsCountAll)
					}
					fctFacets.Counts = fctFacetsCount
					facets = append(facets, fctFacets)
				}
			}

			// fmt.Println("******* ", facet_counts["count"])
			// fmt.Println("::::::: ", facet_counts["date_req"])
			r.Results.FacetsJson = facets
			r.Results.NumFacets = len(facets)
		}
	}

	facet_response, ok := response_root["facet_counts"].(interface{})
	if ok == true {
		facet_counts := facet_response.(map[string]interface{})
		if facet_counts != nil {
			facet_fields := facet_counts["facet_fields"].(map[string]interface{})
			facets := []Facet{}
			if facet_fields != nil {
				facets = make([]Facet, 0, len(facet_fields))
				for k, v := range facet_fields {
					f := Facet{Name: k}
					chunked := chunk(v.([]interface{}), facet_chunk_size)
					lc := len(chunked)
					for i := 0; i < lc; i++ {
						f.Counts = append(f.Counts, FacetCount{
							Value: chunked[i][0].(string),
							Count: int(chunked[i][1].(float64)),
						})
					}
					facets = append(facets, f)
				}
			}

			r.Results.Facets = facets
			r.Results.NumFacets = len(facets)
			allRange := []Facet{}
			facet_ranges := facet_counts["facet_ranges"].(map[string]interface{})
			if facet_ranges != nil {
				//facetRanges := []Facet{}
				allRange = make([]Facet, 0, len(facet_ranges))
				for k, v := range facet_ranges {
					f := Facet{Name: k}
					chunked := chunk(v.(map[string]interface{})["counts"].([]interface{}), facet_chunk_size)
					lc := len(chunked)
					for i := 0; i < lc; i++ {
						f.Counts = append(f.Counts, FacetCount{
							Value: chunked[i][0].(string),
							Count: int(chunked[i][1].(float64)),
						})
					}
					allRange = append(allRange, f)
				}
			}
			r.Results.FacetRanges = allRange

			facet_queries := facet_counts["facet_queries"].(map[string]interface{})
			facetQueries := []FacetCount{}
			if facet_queries != nil {
				facetQueries = make([]FacetCount, 0, len(facet_queries))
				for k, v := range facet_queries {
					facetQueries = append(facetQueries, FacetCount{
						Value: k,
						Count: int(v.(float64)),
					})
				}
			}

			r.Results.NumFacetQueries = len(facetQueries)
			r.Results.FacetQueries = facetQueries
		}
	}

	stats_response, ok := response_root["stats"].(interface{})
	if ok {
		stats := stats_response.(map[string]interface{})
		if stats != nil {
			stats_fields := stats["stats_fields"].(map[string]interface{})
			sfields := Stats{}
			if stats_fields != nil {
				// docstatfieldss := []DocStatsFields{}
				docstatfieldss := map[string]interface{}{}
				for k, v := range stats_fields {
					if v != nil {
						docstatfieldss[k] = v.(map[string]interface{})
						// statsfields := DocStatsFields{k, v.(map[string]interface{})}
						// docstatfieldss = append(docstatfieldss, statsfields)
					}
				}
				sfields.StatsFields = docstatfieldss
				r.Results.Stats = sfields
			}
		}
	}

	return &r, nil
}

func chunk(s []interface{}, sz int) [][]interface{} {
	r := [][]interface{}{}
	j := len(s)
	for i := 0; i < j; i += sz {
		r = append(r, s[i:i+sz])
	}
	return r
}

func StatusErrorResponse(m map[string]interface{}) (bool, *ErrorResponse) {
	if _, err := m["error"]; err {
		error := m["error"].(map[string]interface{})
		return true, &ErrorResponse{
			Message: error["msg"].(string),
			Status:  int(error["code"].(float64)),
		}
	}

	return false, nil
}

func NewQuery() *Query {
	q := new(Query)
	q.params = &url.Values{}
	return q
}

func (q *Query) AddParam(key, val string) {
	q.params.Add(key, val)
}

func (q *Query) RemoveParam(key string) {
	q.params.Del(key)
}

func (q *Query) GetParam(key string) string {
	return q.params.Get(key)
}

func (q *Query) SetParam(key, val string) {
	q.params.Set(key, val)
}

func (q *Query) Q(qs string) {
	q.params.Add("q", qs)
}

func (q *Query) Sort(sort string) {
	q.params.Add("sort", sort)
}

func (q *Query) FilterQuery(fq string) {
	q.params.Add("fq", fq)
}

func (q *Query) FieldList(fl string) {
	q.params.Add("fl", fl)
}

func (q *Query) Start(start int) {
	q.params.Set("start", fmt.Sprintf("%d", start))
}

func (q *Query) Rows(rows int) {
	q.params.Set("rows", fmt.Sprintf("%d", rows))
}

func (q *Query) String() string {
	return q.params.Encode()
}

func (q *Query) AddFacet(f string) {
	q.params.Set("facet", "true")
	q.params.Add("facet.field", f)
}

func (q *Query) Deftype(d string) {
	q.params.Add("deftype", d)
}

func (q *Query) QueryFields(qf string) {
	q.params.Add("qf", qf)
}

func (q *Query) BoostQuery(bq string) {
	q.params.Add("bq", bq)
}

func (d *DocumentCollection) Get(i int) *Document {
	return &d.Collection[i]
}

func (d *DocumentCollection) Len() int {
	return len(d.Collection)
}

func (document Document) Field(field string) interface{} {
	r, _ := document.Fields[field]
	return r
}

func (document Document) Doc() map[string]interface{} {
	return document.Fields
}

func (d *DocumentCollection) GetStats(field string) interface{} {
	return d.Stats.StatsFields[field]
}
