package solr

import (
	"encoding/json"
	"fmt"
	"github.com/eaciit/toolkit"
	"testing"
)

func PrepareConnection() (*ConnectionInfo, error) {
	conn, err := NewConnection("192.168.0.230", 8983, "songs3")
	return conn, err
}
func TestConnection(t *testing.T) {
	t.Skip()
	_, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}
}

func TestFetchData(t *testing.T) {
	t.Skip()
	c, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	q := NewQuery()
	q.Q("*:*")
	// q.Q("song")
	q.FilterQuery("song_name:kisah kita")
	q.FilterQuery("song_id:110111431")
	q.Sort("_version_ desc")
	q.Start(0)
	q.Rows(10)
	q.AddFacet("song_id")

	res, err := c.Select(q)
	if err != nil {
		t.Errorf("Data not select : %s", err.Error())
	}
	results := res.Results
	fmt.Println(results.NumFacets)

	// fmt.Println(
	// 	fmt.Sprintf("Query: %#v\nHits: %d\nNum Results: %d\nQtime: %d\nStatus: %d\n\nResults\n-------\n",
	// 		q.params.Encode(),
	// 		results.NumFound,
	// 		results.Len(),
	// 		res.QTime,
	// 		res.Status))

	// for i := 0; i < results.Len(); i++ {
	// 	fmt.Println("songid:", results.Get(i).Field("song_id"))
	// 	fmt.Println("songname:", results.Get(i).Field("song_name"))
	// 	fmt.Println("keyword:", results.Get(i).Field("search_keyword"))

	// 	fmt.Println("")

	// loop over facets returned
	for i := 0; i < results.NumFacets; i++ {
		facet := results.Facets[i]
		fmt.Println("Facet:", facet.Name)
		lfc := len(facet.Counts)
		for j := 0; j < lfc; j++ {
			fmt.Println(facet.Counts[j].Value, "=>", facet.Counts[j].Count)
		}
		fmt.Println("")
	}
}

func TestFetchDataEdismax(t *testing.T) {
	t.Skip()
	c, e := NewConnection("localhost", 7337, "techproducts")
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	q := NewQuery()
	q.Q("ipod+OR+video")
	q.Sort("_version_ desc")
	q.Start(0)
	q.Rows(10)
	q.Deftype("edismax")
	q.QueryFields("features^20.0+text^0.3")

	res, err := c.Select(q)
	if err != nil {
		t.Errorf("Data not select : %s", err.Error())
	}
	results := res.Results

	fmt.Println(fmt.Sprintf("Query: %#v\nHits: %d\nNum Results: %d\nQtime: %d\nStatus: %d\n\nResults\n-------\n",
		q.params.Encode(),
		results.NumFound,
		results.Len(),
		res.QTime,
		res.Status))

	for i := 0; i < results.Len(); i++ {
		// fmt.Println("songid:", results.Get(i).Field("song_id"))
		// fmt.Println("songname:", results.Get(i).Field("song_name"))
		// fmt.Println("keyword:", results.Get(i).Field("search_keyword"))
		fmt.Println(results.Get(i).Doc())

		fmt.Println("")
	}
}

func TestAddSingleJsonDoc(t *testing.T) {
	t.Skip()
	c, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	tm := toolkit.M{"id": "4", "title": "Ddqwfqwfwf"}
	q := NewQuery()
	q.AddParam("commit", "true")

	_, err := c.AddSingle(tm, q)
	if err != nil {
		t.Errorf("Update Error : %s", err.Error())
	}
	// fmt.Println(tm)
	// var jsonData, err = json.Marshal(tm)
	// if err != nil {
	// 	fmt.Println(err.Error())
	// }

	// fmt.Println(string(jsonData))
}

func TestAddMultiJsonDoc(t *testing.T) {
	t.Skip()
	c, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	tm1 := toolkit.M{"id": "3", "title": "Doc 133"}
	tm2 := toolkit.M{"id": "2", "title": "Doc 2"}
	tms := toolkit.Ms{
		tm1, tm2,
	}

	q := NewQuery()
	q.AddParam("commit", "true")
	_, err := c.AddMulti(tms, q)
	if err != nil {
		t.Errorf("Update Error : %s", err.Error())
	}
}

func TestAddFileJsonDoc(t *testing.T) {
	t.Skip()
	_, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

}

func TestEditDoc(t *testing.T) {
	t.Skip()
	c, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	tm := toolkit.M{"id": "4", "title": "halo"}
	q := NewQuery()
	q.AddParam("commit", "true")
	_, err := c.EditSingle(tm, q)
	if err != nil {
		//t.Errorf("Update Error : %s", err.Error())
		fmt.Println(err)
	}
}

func TestDeleteDoc(t *testing.T) {
	t.Skip()
	c, e := PrepareConnection()
	if e != nil {
		t.Errorf("Unable to connect: %s \n", e.Error())
	}

	tm := toolkit.M{"query": "id:ae5ad037-cead-4aef-810f-652299af1b84"}
	q := NewQuery()
	q.AddParam("commit", "true")
	_, err := c.Delete(tm, q)
	if err != nil {
		t.Errorf("Update Error : %s", err.Error())
	}
}

func TestCodenew(t *testing.T) {
	t.Skip()
	tm1 := toolkit.M{"id": "3", "title": "Doc 133"}
	tm2 := toolkit.M{"id": "2", "title": "Doc 2"}
	tms := toolkit.Ms{
		tm1, tm2,
	}

	var jsonData, err = json.Marshal(tms)
	if err != nil {
		fmt.Println(err.Error())
	}

	fmt.Println(string(jsonData))

	tms22 := toolkit.M{"delete": toolkit.M{"query": "*:*"}, "wqw": toolkit.M{"ewew": "12334"}}
	var jsonData1, err21 = json.Marshal(tms22)
	if err21 != nil {
		fmt.Println(err21.Error())
	}

	fmt.Println(string(jsonData1))
}
