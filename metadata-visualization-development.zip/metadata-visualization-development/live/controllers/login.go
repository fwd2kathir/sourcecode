package controllers

import (
	"eaciit/scbmetadata/live/helper"

	. "eaciit/scbmetadata/live/models"

	"github.com/eaciit/dbox"
	knot "github.com/eaciit/knot/knot.v1"
	tk "github.com/eaciit/toolkit"
)

type LoginController struct {
	*BaseController
}

func (c *LoginController) Default(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputTemplate
	k.Config.LayoutTemplate = ""
	return ""
}

func (c *LoginController) DefaulUrl(k *knot.WebContext) string {
	defaulurl := ""
	if k.Session("userid") == nil {
		c.Redirect(k, "login", "default")
	} else {
		// Check Roles
		conRole, _ := helper.ConnectJson(c.GetDbRole())
		defer conRole.Close()
		csrRole, _ := conRole.NewQuery().
			Where(dbox.Eq("_id", k.Session("roles"))).Cursor(nil)
		defer csrRole.Close()

		var SysRole []SysRolesModel
		_ = csrRole.Fetch(&SysRole, 0, false)
		defaulurl = SysRole[0].DefaultUrl

	}
	return defaulurl
}

func (c *LoginController) Do(k *knot.WebContext) interface{} {
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson
	formData := struct {
		UserName string
		Password string
	}{}
	message := ""
	isValid := false
	defaulUrl := ""
	err := k.GetPayload(&formData)
	if err != nil {
		c.WriteLog(err)
		message = "Backend Error " + err.Error()
	}

	con, e := helper.ConnectJson(c.GetDbUser())
	if e != nil {
		return tk.M{}.Set("Valid", false).Set("Message", e.Error())
	}

	defer con.Close()
	csr, e := con.NewQuery().
		Where(dbox.And(dbox.Eq("username", formData.UserName), dbox.Eq("password", helper.GetMD5Hash(formData.Password)))).
		Cursor(nil)
	if e != nil {
		return tk.M{}.Set("Valid", false).Set("Message", e.Error())
	}

	if csr == nil {
		return tk.M{}.Set("Valid", false).Set("Message", e.Error())
	}
	defer csr.Close()
	apps := []tk.M{}
	e = csr.Fetch(&apps, 0, false)
	if e != nil {
		message = "Invalid Username or password!"
		isValid = false
	} else {
		if len(apps) > 0 {
			resUser := apps[0]
			k.SetSession("userid", resUser["_id"].(string))
			k.SetSession("username", resUser["username"].(string))
			k.SetSession("fullname", resUser["fullname"].(string))
			k.SetSession("extension", resUser["extension"].(string))
			k.SetSession("roles", resUser["roles"].(string))
			k.SetSession("usermodel", resUser)
			defaulUrl = c.DefaulUrl(k)
			isValid = true

		}
	}
	var userId = ""
	if k.Session("userid") != nil {
		userId = k.Session("userid").(string)
	} else {
		userId = ""
	}
	ret := tk.M{}
	ret.Set("IdUser", userId)
	return tk.M{}.Set("Valid", isValid).Set("Url", defaulUrl).Set("Data", ret).Set("Message", message)
}
