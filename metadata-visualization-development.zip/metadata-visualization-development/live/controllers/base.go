package controllers

import (
	"eaciit/scbmetadata/live/helper"
	. "eaciit/scbmetadata/live/models"
	//. "eaciit/melon/webapp/helper"
	"os"
	"path/filepath"

	"gopkg.in/mgo.v2/bson"
	// "errors"
	"fmt"
	"log"
	"math"
	"net/http"
	// "path/filepath"

	//"github.com/eaciit/acl/v1.0"
	//db "github.com/eaciit/dbox"
	"github.com/eaciit/crowd"
	"github.com/eaciit/dbox"
	"github.com/eaciit/knot/knot.v1"
	//"github.com/eaciit/orm"
	tk "github.com/eaciit/toolkit"
	//"gopkg.in/mgo.v2"
	//"gopkg.in/mgo.v2/bson"
	"strconv"
	"strings"
	"time"
)

type IBaseController interface {
}
type BaseController struct {
	//base            IBaseController
	//Ctx             *orm.DataContext
	UploadPath      string
	Path            string
	AccessKeyID     string
	SecretAccessKey string
	Endpoint        string
	AccAmazone      string
	Attachemail     string
	SMTPAddress     string
	SMTPPort        int
	SMTPUsername    string
	SMTPPassword    string
	SenderMail      string
	SenderName      string
	AppStatus       string
	AppUrl          string
	Username        string
	Password        string
	Source          string
	Host            string
	Database        string
}

type PageInfo struct {
	PageTitle    string
	SelectedMenu string
	Breadcrumbs  map[string]string
}

type ResultInfo struct {
	IsError bool
	Message string
	Total   int
	Data    interface{}
	//
	StartTime time.Time
	Action    string
}

type Previlege struct {
	View     bool
	Create   bool
	Edit     bool
	Delete   bool
	Approve  bool
	Process  bool
	Menuid   string
	Menuname string
	Username string
}

// func (b *BaseController) LoadBaseUrl(k *knot.WebContext) {

// 	k.Config.NoLog = true
// 	b.IsAuthenticate(k)

// 	return
// }

// func (b *BaseController) LoadBaseAjaxServ(k *knot.WebContext) {
// 	k.Config.NoLog = true

// 	sessionid := tk.ToString(k.Session("sessionid", ""))
// 	if !acl.IsSessionIDActive(sessionid) {
// 		// return errors.New("Session Expired")
// 	}

// 	return
// }

func (b *BaseController) LoadBase(k *knot.WebContext) []tk.M {
	k.Config.NoLog = true
	b.IsAuthenticate(k)
	return []tk.M{}
}

// func (b *BaseController) LogBase(k *knot.WebContext, res *ResultInfo) {

// 	// tk.Println("============= Check Header: ", k.Request.Header, "=============")
// 	ilog := new(acl.Log)
// 	ilog.ID = tk.RandomString(32)
// 	ilog.SessionId = tk.ToString(k.Session("sessionid", ""))
// 	ilog.LoginId = tk.ToString(k.Session("username", ""))
// 	ilog.Action = res.Action
// 	// ilog.Reference = k.Request.Header.Get("Referer")
// 	ilog.Reference = k.Request.RequestURI
// 	ilog.RequestAddr = k.Request.Header.Get("REMOTE_ADDR")
// 	ilog.Time = res.StartTime
// 	ilog.LoadingTimes = time.Since(res.StartTime).String()

// 	payload := tk.M{}
// 	_ = k.GetPayload(&payload)
// 	tkm := tk.M{}.Set("iserror", res.IsError).Set("message", res.Message).Set("payload", payload)
// 	ilog.Description = tk.JsonString(tkm)

// 	_ = acl.Save(ilog)
// 	//saving log data in file
// 	/*
// 		t1 := time.Now().UTC()
// 		filelog, _ := filepath.Abs(filepath.Join(b.Path, "log", tk.Sprintf("log-%d%d.csv", t1.Month(), t1.Year())))
// 		for {
// 			workerconn, er := helper.PrepareConnectionLogFile(filelog)
// 			if er == nil {
// 				_ = workerconn.NewQuery().
// 					SetConfig("multiexec", true).
// 					Save().Exec(tk.M{}.Set("data", ilog))
// 				defer workerconn.Close()
// 				break
// 			}
// 		}
// 	*/

// 	return
// }

func (b *BaseController) IsAuthenticate(k *knot.WebContext) {
	url := k.Request.URL.String()
	if strings.Index(url, "?") > -1 {
		url = url[:strings.Index(url, "?")]
	}

	if k.Session("userid") == nil {
		b.Redirect(k, "login", "default")
	} else {
		conMenu, _ := helper.ConnectJson(b.GetDbMenu())

		defer conMenu.Close()
		csrMenu, _ := conMenu.NewQuery().
			Where(dbox.Eq("Url", url)).Cursor(nil)
		fmt.Println(url, b.GetDbMenu())
		defer csrMenu.Close()
		dataMenu := []tk.M{}
		_ = csrMenu.Fetch(&dataMenu, 0, false)

		idMenu := dataMenu[0]["_id"].(string)

		// Check Roles
		conRole, _ := helper.ConnectJson(b.GetDbRole())
		defer conRole.Close()
		csrRole, _ := conRole.NewQuery().
			Where(dbox.Eq("_id", k.Session("roles"))).Cursor(nil)
		defer csrRole.Close()

		var SysRole []SysRolesModel
		_ = csrRole.Fetch(&SysRole, 0, false)
		datas := SysRole[0].Menu

		docField := SysRolesModel{}
		tempMenu := docField.Menu
		tempMenu = datas

		exist := len(crowd.From(&tempMenu).Where(func(x interface{}) interface{} {
			y := x.(Detailsmenu).Menuid == idMenu && x.(Detailsmenu).Access == true
			return y
		}).Exec().Result.Data().([]Detailsmenu))
		if exist == 0 {
			b.Redirect(k, "page", "notfound")
		}

	}
}

var (
	WD_PATH string = func() string {
		d, _ := os.Getwd()
		return d + "/"
	}()
)

func (b *BaseController) GetDbMenu() string {
	return filepath.Join(WD_PATH, "live", "conf", "dbmenu.json")
}

func (b *BaseController) GetDbRole() string {
	return filepath.Join(WD_PATH, "live", "conf", "dbrole.json")
}
func (b *BaseController) GetDbUser() string {
	return filepath.Join(WD_PATH, "live", "conf", "dbuser.json")
}

// func (b *BaseController) AccessMenu(k *knot.WebContext) []tk.M {
// 	url := k.Request.URL.String()
// 	if strings.Index(url, "?") > -1 {
// 		url = url[:strings.Index(url, "?")]
// 		//		tk.Println("URL_PARSED,", url)
// 	}
// 	sessionRoles := k.Session("roles")
// 	access := []tk.M{}
// 	if sessionRoles != nil {
// 		accesMenu := sessionRoles.([]SysRolesModel)
// 		if len(accesMenu) > 0 {
// 			for _, o := range accesMenu[0].Menu {
// 				if o.Url == url {
// 					obj := tk.M{}
// 					obj.Set("View", o.View)
// 					obj.Set("Create", o.Create)
// 					obj.Set("Approve", o.Approve)
// 					obj.Set("Delete", o.Delete)
// 					obj.Set("Process", o.Process)
// 					obj.Set("Edit", o.Edit)
// 					obj.Set("Menuid", o.Menuid)
// 					obj.Set("Menuname", o.Menuname)
// 					obj.Set("Username", k.Session("username").(string))
// 					access = append(access, obj)
// 					return access
// 				}

// 			}
// 		}
// 	}
// 	return access
// }

func (b *BaseController) IsLoggedIn(k *knot.WebContext) bool {
	if k.Session("userid") == nil {
		return false
	}
	return true
}
func (b *BaseController) GetCurrentUser(k *knot.WebContext) string {
	if k.Session("userid") == nil {
		return ""
	}
	return k.Session("username").(string)
}
func (b *BaseController) Redirect(k *knot.WebContext, controller string, action string) {
	// log.Println("StandchartORF -->> redirecting to " + controller + "/" + action)
	http.Redirect(k.Writer, k.Request, "/"+controller+"/"+action, http.StatusTemporaryRedirect)
}

func (b *BaseController) CokRedirect(k *knot.WebContext, service string, controller string, action string) {
	// log.Println("StandchartORF -->> redirecting to " + controller + "/" + action)
	http.Redirect(k.Writer, k.Request, "/"+service+"/"+controller+"/"+action, http.StatusTemporaryRedirect)
}

func (b *BaseController) WriteLog(msg interface{}) {
	log.Printf("%#v\n\r", msg)
	return
}

func (b *BaseController) InitialResultInfo(act, msg string) ResultInfo {
	r := ResultInfo{}
	r.IsError = true
	r.Message = msg
	r.Action = act
	r.StartTime = time.Now()
	return r
}

func (b *BaseController) SetResultInfo(isError bool, msg string, data interface{}) ResultInfo {
	r := ResultInfo{}
	r.IsError = isError
	r.Message = msg
	r.Data = data
	return r
}

func (b *BaseController) ErrorResultInfo(msg string, data interface{}) ResultInfo {
	r := ResultInfo{}
	r.IsError = true
	r.Message = msg
	r.Data = data
	return r
}
func (b *BaseController) Round(f float64) float64 {
	return math.Floor(f + .5)
}
func (b *BaseController) RoundPlus(f float64, places int) float64 {
	shift := math.Pow(10, float64(places))
	return b.Round(f*shift) / shift
}
func (b *BaseController) FirstMonday(year int, mn int) int {
	month := time.Month(mn)
	t := time.Date(year, month, 1, 0, 0, 0, 0, time.UTC)

	d0 := (8-int(t.Weekday()))%7 + 1
	s := strconv.Itoa(year) + fmt.Sprintf("%02d", mn) + fmt.Sprintf("%02d", d0)
	ret, _ := strconv.Atoi(s)
	return ret
}

func (b *BaseController) FirstWorkDay(ym string) int {
	t, err := time.Parse("2006-01-02", ym+"-01")
	if err != nil {
		fmt.Println(err.Error())
	}
	for t.Weekday() == 0 || t.Weekday() == 6 {
		if t.Weekday() == 0 {
			t = t.AddDate(0, 0, 1)
		} else if t.Weekday() == 6 {
			t = t.AddDate(0, 0, 2)
		}
	}
	ret, _ := strconv.Atoi(t.Format("20060102"))
	return ret
}

// func (b *BaseController) GetNextIdSeq(collName string) (int, error) {
// 	ret := 0
// 	mdl := NewSequenceModel()
// 	crs, err := b.Ctx.Find(NewSequenceModel(), tk.M{}.Set("where", db.Eq("collname", collName)))
// 	if err != nil {
// 		return -9999, err
// 	}
// 	defer crs.Close()
// 	err = crs.Fetch(mdl, 1, false)
// 	if err != nil {
// 		return -9999, err
// 	}
// 	ret = mdl.Lastnumber + 1
// 	mdl.Lastnumber = ret
// 	b.Ctx.Save(mdl)
// 	return ret, nil
// }

// func (b *BaseController) ToFixed(num float64, precision int) float64 {
// 	output := math.Pow(10, float64(precision))
// 	return float64(b.Rounded(num*output)) / output
// }

// func (b *BaseController) Rounded(num float64) int {
// 	return int(num + math.Copysign(0.5, num))
// }

// func (b *BaseController) DistinctArrayString(xs *[]string) {
// 	found := make(map[string]bool)
// 	j := 0
// 	for i, x := range *xs {
// 		if !found[x] {
// 			found[x] = true
// 			(*xs)[j] = (*xs)[i]
// 			j++
// 		}
// 	}
// 	*xs = (*xs)[:j]
// }

func (b *BaseController) FormatDateString(valuedate string, formatnow string, formatDestination string) (string, error) {

	t, err := time.Parse(formatnow, valuedate)
	if err != nil {
		return "", err
	}
	result := t.Format(formatDestination)

	return result, nil
}

func (b *BaseController) PercentageValue(firstvalue float64, secondvalue float64) float64 {

	final := 0.00
	if secondvalue != 0.00 {
		final = firstvalue / secondvalue * 100
	}

	return final
}

func (b *BaseController) GetColor(value float64, vsone float64, vstwo float64, vsthree float64) string {

	color := ""
	if value <= vsone {
		color = "Red"
	} else if value > vsthree {
		color = "Green"
	} else {
		color = "Amber"
	}

	return color
}

type DefaultCollection struct {
	Id bson.ObjectId `bson:"_id" , json:"_id" `
}

// func MgoQuery(tablename string, action string, indexAll []string, newtablename string, indexname string) error {
// 	config := ReadConfig()
// 	info := new(mgo.DialInfo)
// 	info.Username = config["username"]
// 	info.Password = config["password"]
// 	info.Source = config["source"]
// 	info.Addrs = []string{config["host"]}
// 	info.Database = config["database"]

// 	session, err := mgo.DialWithInfo(info)
// 	if err != nil {
// 		return err
// 	}
// 	defer session.Close()

// 	// Error check on every access
// 	session.SetSafe(&mgo.Safe{})

// 	// Get collection
// 	collection := session.DB(info.Database).C(tablename)

// 	switch action {
// 	case "Remove":
// 		err = collection.Remove(bson.M{})
// 		break
// 	case "RemoveAll":
// 		_, err = collection.RemoveAll(bson.M{})
// 		break
// 	case "DropCollection":
// 		err = collection.DropCollection()
// 		break
// 	case "CountCollection":
// 		total := 0
// 		total, err = collection.Count()
// 		strMessage := tk.ToString(total)
// 		messageError := errors.New(strMessage)
// 		return messageError
// 		break
// 	case "StatusServer":
// 		result := tk.M{}
// 		err = session.DB(info.Database).Run("dbstats", &result)
// 		strMessage := result.GetString("numExtents") + "$$$" + result.GetString("indexes") + "$$$" + result.GetString("collections") + "$$$" +
// 			result.GetString("objects") + "$$$" + result.GetString("storageSize") + "$$$" + result.GetString("indexSize") + "$$$" +
// 			result.GetString("db") + "$$$" + result.GetString("ok") + "$$$" + result.GetString("avgObjSize") + "$$$" + result.GetString("dataSize")
// 		messageError := errors.New(strMessage)
// 		return messageError
// 		break
// 	case "RenameCollection":
// 		a := []interface{}{}
// 		sourceCollection := info.Database + "." + tablename
// 		destinationCollection := info.Database + "." + newtablename
// 		session.Run(bson.D{{"renameCollection", sourceCollection}, {"to", destinationCollection}}, a)
// 		break
// 	case "CreateCollection":
// 		// info := mgo.CollectionInfo{
// 		// 	Capped:   true,
// 		// 	MaxBytes: 1000000,
// 		// }
// 		// err = collection.Create(info) //--> Use Create but failed
// 		// err = collection.Insert(&DefaultCollection{Id: bson.NewObjectId()})  //--> use insert _id success --> will have one row with field _id

// 		a := []interface{}{}
// 		session.DB(info.Database).Run(bson.D{{"create", tablename}}, a)
// 		break
// 	case "CreateIndex":
// 		index := mgo.Index{
// 			Key:        indexAll,
// 			Unique:     false,
// 			DropDups:   true,
// 			Background: true,
// 			Sparse:     true,
// 			Name:       indexname,
// 		}

// 		err = collection.EnsureIndex(index)
// 		break
// 	default:
// 		break
// 	}

// 	if err != nil {
// 		return err
// 	}

// 	return nil
// }

func RoundUp(input float64, places int) (newVal float64) {
	var round float64
	pow := math.Pow(10, float64(places))
	digit := pow * input
	round = math.Ceil(digit)
	newVal = round / pow
	return
}

// func ByteFormat(inputNum float64, precision int) float64 {

// 	if precision <= 0 {
// 		precision = 1
// 	}

// 	//var unit string
// 	var returnVal float64

// 	if inputNum >= 1000000000000000000000000 {
// 		returnVal = RoundUp((inputNum / 1208925819614629174706176), precision)
// 		//unit = " YB" // yottabyte
// 	} else if inputNum >= 1000000000000000000000 {
// 		returnVal = RoundUp((inputNum / 1180591620717411303424), precision)
// 		//unit = " ZB" // zettabyte
// 	} else if inputNum >= 10000000000000000000 {
// 		returnVal = RoundUp((inputNum / 1152921504606846976), precision)
// 		// unit = " EB" // exabyte
// 	} else if inputNum >= 1000000000000000 {
// 		returnVal = RoundUp((inputNum / 1125899906842624), precision)
// 		// unit = " PB" // petabyte
// 	} else if inputNum >= 1000000000000 {
// 		returnVal = RoundUp((inputNum / 1099511627776), precision)
// 		// unit = " TB" // terrabyte
// 	} else if inputNum >= 1000000000 {
// 		returnVal = RoundUp((inputNum / 1073741824), precision)
// 		// unit = " GB" // gigabyte
// 	} else if inputNum >= 1000000 {
// 		returnVal = RoundUp((inputNum / 1048576), precision)
// 		// unit = " MB" // megabyte
// 	} else if inputNum >= 1000 {
// 		returnVal = RoundUp((inputNum / 1024), precision)
// 		// unit = " KB" // kilobyte
// 	} else {
// 		returnVal = inputNum
// 		// unit = " bytes" // byte
// 	}

// 	//return strconv.FormatFloat(returnVal, 'f', precision, 64) + unit
// 	return returnVal
// }
