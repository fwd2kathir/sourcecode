package controllers

import (
	"eaciit/melon/library/solr"
	"fmt"
	"strings"

	"github.com/eaciit/knot/knot.v1"
)

//tk "github.com/eaciit/toolkit"
//"strings"

type DashboardController struct {
	*BaseController
}

func (c *DashboardController) Default(k *knot.WebContext) interface{} {
	access := c.LoadBase(k)
	k.Config.NoLog = true
	//k.Config.IncludeFiles = []string{"dashboard/dashboard-fte-resources.html", "dashboard/dashboard-in-entity.html", "dashboard/dashboard-intra-group.html", "dashboard/dashboard-intra-receiver.html", "dashboard/dashboard-intra-supplier.html", "dashboard/dashboard-external.html", "dashboard/dashboard-external-receiver.html", "dashboard/dashboard-external-supplier.html", "dashboard/dashboard-asetss.html", "dashboard/dashboard-aseets-receiver.html", "dashboard/dashboard-aseets-supplier.html", "dashboard/dashboard-fmi.html", "dashboard/dashboard-fmi-receiver.html", "dashboard/dashboard-fmi-supplier.html"}
	k.Config.OutputType = knot.OutputTemplate
	k.Config.OutputType = knot.OutputTemplate
	DataAccess := Previlege{}

	for _, o := range access {
		DataAccess.Create = o["Create"].(bool)
		DataAccess.View = o["View"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Process = o["Process"].(bool)
		DataAccess.Delete = o["Delete"].(bool)
		DataAccess.Edit = o["Edit"].(bool)
		DataAccess.Menuid = o["Menuid"].(string)
		DataAccess.Menuname = o["Menuname"].(string)
		DataAccess.Approve = o["Approve"].(bool)
		DataAccess.Username = o["Username"].(string)
	}

	return DataAccess
}

type ResponseDefault struct {
	IsError bool
	Data    interface{}
	Message string
}
type FilterSystemDataRequest struct {
	EDMSourceSystem string
	ITAM_REF        string
	ITAMStatus      string
	ITAMSourceName  string
	AnyField        string
	Page            int
	PerPage         int
}

func BuildQuerySystemData(filter FilterSystemDataRequest) *solr.Query {
	query := solr.NewQuery()
	allQuery := []string{}
	if filter.EDMSourceSystem != "" {
		allQuery = append(allQuery, fmt.Sprintf("EDMSourceSystem:%s", filter.EDMSourceSystem))
		//paramQ += "EDMSourceSystem:"
	}
	if filter.ITAM_REF != "" {
		allQuery = append(allQuery, fmt.Sprintf("ITAM_REF:%s", filter.ITAM_REF))
		//paramQ += "EDMSourceSystem:"
	}
	if filter.ITAMStatus != "" {
		allQuery = append(allQuery, fmt.Sprintf("ITAMStatus:%s", filter.ITAMStatus))
		//paramQ += "EDMSourceSystem:"
	}
	if filter.ITAMSourceName != "" {
		allQuery = append(allQuery, fmt.Sprintf("ITAMSourceName:%s", filter.ITAMStatus))
		//paramQ += "EDMSourceSystem:"
	}
	if filter.AnyField != "" {
		allQuery = append(allQuery, fmt.Sprintf("%s", filter.ITAMStatus))
		//paramQ += "EDMSourceSystem:"
	}

	paramQ := strings.Join(allQuery, " AND ")
	query.Q(paramQ)
	return query
}
func (c *DashboardController) FilterSystemData(k *knot.WebContext) interface{} {
	c.LoadBase(k)
	k.Config.NoLog = true
	k.Config.OutputType = knot.OutputJson
	hasil := ResponseDefault{}
	oo := FilterSystemDataRequest{}
	err := k.GetPayload(&oo)
	conn, err := solr.NewConnection("52.76.247.30", 8983, "edmsrc")
	if err != nil {
		hasil.IsError = true
		hasil.Message = err.Error()
		return hasil
	}

	query := BuildQuerySystemData(oo)
	res, err := conn.Select(query)
	if err != nil {
		hasil.IsError = true
		hasil.Message = err.Error()
		return hasil
	}
	hasil.Data = res.Results.Collection
	return hasil
}
