package models

import (
	"github.com/eaciit/orm"
)

type TopMenuModel struct {
	orm.ModelBase `json:"-"`
	Id            string `json:"_id"`
	PageId        string `json:"PageId"`
	Parent        string `json:"Parent"`
	Title         string `json:"Title"`
	Url           string `json:"Url"`
	IndexMenu     int    `json:"IndexMenu"`
	Enable        bool   `json:"Enable"`
	Haschild      bool   `json:"haschild"`
	Icon          string `json:"icon"`
	StatusMenu    string `json:"StatusMenu"`
}

func NewTopMenuModel() *TopMenuModel {
	m := new(TopMenuModel)
	return m
}

func (e *TopMenuModel) RecordID() interface{} {
	return e.Id
}

func (m *TopMenuModel) TableName() string {
	return "SysMenu"
}
